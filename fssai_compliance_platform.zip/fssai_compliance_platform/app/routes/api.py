"""
REST API Blueprint
AI-Based Food Label Compliance Verification Platform
"""

from flask import Blueprint, jsonify, request
from app.models import ScanRecord
from app.services.fssai_rules import FSSAIRuleVerifier, FIELD_DEFINITIONS
from app.services.ml_classifier import ComplianceClassifier

api_bp = Blueprint("api", __name__)


@api_bp.route("/verify_text", methods=["POST"])
def verify_text():
    """Programmatic API to verify raw label text against the 14 FSSAI fields."""
    data = request.get_json() or {}
    text = data.get("text", "").strip()

    if not text:
        return jsonify({"error": "No 'text' field provided in request body."}), 400

    rule_eval = FSSAIRuleVerifier.verify_all(text)
    ml_eval = ComplianceClassifier.predict(text)

    return jsonify({
        "success": True,
        "score": rule_eval["score"],
        "compliance_status": rule_eval["compliance_status"],
        "status_description": rule_eval["status_description"],
        "ml_prediction": ml_eval["prediction"],
        "ml_confidence": ml_eval["confidence"],
        "fields": rule_eval["fields"]
    })


@api_bp.route("/metrics", methods=["GET"])
def get_metrics():
    """Returns actual test metrics from the TF-IDF + Logistic Regression model."""
    metrics = ComplianceClassifier.get_metrics()
    return jsonify(metrics)


@api_bp.route("/scans", methods=["GET"])
def list_scans():
    """Returns recent audit scan summaries."""
    limit = min(int(request.args.get("limit", 20)), 100)
    scans = ScanRecord.query.order_by(ScanRecord.created_at.desc()).limit(limit).all()
    return jsonify([s.to_dict() for s in scans])
