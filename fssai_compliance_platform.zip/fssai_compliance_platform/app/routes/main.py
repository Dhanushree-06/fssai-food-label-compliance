"""
Main Blueprint Routes (Home, About, ZIP Download)
AI-Based Food Label Compliance Verification Platform
"""

import os
import shutil
import zipfile
from flask import Blueprint, render_template, send_file, current_app
from app.models import ScanRecord
from app.services.ml_classifier import ComplianceClassifier
from app.services.fssai_rules import FIELD_DEFINITIONS

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """Platform landing page with summary stats, regulations overview, and recent audits."""
    total_scans = ScanRecord.query.count()
    compliant_scans = ScanRecord.query.filter_by(compliance_status="COMPLIANT").count()
    pass_rate = round((compliant_scans / max(total_scans, 1)) * 100, 1) if total_scans > 0 else 0.0

    recent_scans = ScanRecord.query.order_by(ScanRecord.created_at.desc()).limit(5).all()

    return render_template(
        "index.html",
        total_scans=total_scans,
        compliant_scans=compliant_scans,
        pass_rate=pass_rate,
        recent_scans=recent_scans,
        fields_definitions=FIELD_DEFINITIONS
    )


@main_bp.route("/about")
def about():
    """About page with FSSAI regulations, 14 fields specification, and honest ML test metrics."""
    metrics = ComplianceClassifier.get_metrics()
    return render_template(
        "about.html",
        metrics=metrics,
        fields_definitions=FIELD_DEFINITIONS
    )


@main_bp.route("/download-zip")
def download_zip():
    """Generates on-the-fly or delivers the project ZIP package."""
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    zip_path = os.path.join(base_dir, "fssai_compliance_platform.zip")

    # If ZIP doesn't exist, create it
    if not os.path.exists(zip_path):
        from create_zip import create_project_zip
        create_project_zip()

    if os.path.exists(zip_path):
        return send_file(
            zip_path,
            as_attachment=True,
            download_name="fssai_compliance_platform.zip",
            mimetype="application/zip"
        )
    return "ZIP archive not available", 404
