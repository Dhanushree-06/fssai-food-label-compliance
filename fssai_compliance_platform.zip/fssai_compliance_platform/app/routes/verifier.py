"""
Verifier Blueprint Routes
AI-Based Food Label Compliance Verification Platform
"""

import os
import json
import shutil
from datetime import datetime
from werkzeug.utils import secure_filename
from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file, current_app
)
from app.models import db, ScanRecord, FieldResult
from app.services.image_processing import ImagePreprocessor
from app.services.ocr_engine import OCREngine
from app.services.fssai_rules import FSSAIRuleVerifier, FIELD_DEFINITIONS
from app.services.ml_classifier import ComplianceClassifier
from app.services.pdf_generator import PDFReportGenerator

verifier_bp = Blueprint("verifier", __name__)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@verifier_bp.route("/verify", methods=["GET", "POST"])
def verify():
    """Upload food label image or choose a sample label for compliance audit."""
    if request.method == "POST":
        sample_choice = request.form.get("sample_choice")
        uploaded_file = request.files.get("label_image")

        upload_dir = current_app.config["UPLOAD_FOLDER"]
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Determine input image
        if sample_choice:
            sample_dir = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "static", "sample_images"
            )
            src_path = os.path.join(sample_dir, sample_choice)
            if not os.path.exists(src_path):
                flash("Selected sample image not found.", "danger")
                return redirect(url_for("verifier.verify"))

            target_filename = f"scan_{timestamp_str}_{sample_choice}"
            target_path = os.path.join(upload_dir, target_filename)
            shutil.copyfile(src_path, target_path)
            display_name = sample_choice.replace("sample_", "").replace(".png", "").replace("_", " ").title()
        elif uploaded_file and uploaded_file.filename != "":
            if not allowed_file(uploaded_file.filename):
                flash("Invalid file format. Please upload PNG, JPG, JPEG, or WEBP.", "danger")
                return redirect(url_for("verifier.verify"))

            clean_name = secure_filename(uploaded_file.filename)
            target_filename = f"scan_{timestamp_str}_{clean_name}"
            target_path = os.path.join(upload_dir, target_filename)
            uploaded_file.save(target_path)
            display_name = clean_name.rsplit(".", 1)[0].replace("_", " ").title()
        else:
            flash("Please upload an image or choose one of the pre-loaded sample labels.", "warning")
            return redirect(url_for("verifier.verify"))

        # Preprocessing options
        preproc_opts = {
            "enable_deskew": request.form.get("enable_deskew") == "on",
            "enable_denoise": request.form.get("enable_denoise") == "on",
            "enable_clahe": request.form.get("enable_clahe") == "on",
            "enable_threshold": request.form.get("enable_threshold") == "on"
        }

        # Step 1: OpenCV Preprocessing
        try:
            preproc_res = ImagePreprocessor.preprocess_pipeline(target_path, preproc_opts)
            preprocessed_filename = preproc_res["processed_filename"]
        except Exception as e:
            print(f"[Verifier] Preprocessing error: {e}")
            preprocessed_filename = None

        # Step 2: OpenCV Veg/Non-Veg Symbol Detection
        cv_symbol = ImagePreprocessor.detect_veg_nonveg_symbol(target_path)

        # Step 3: OCR Text & Bounding Box Extraction
        ocr_result = OCREngine.extract_text(target_path)
        extracted_text = ocr_result["full_text"]
        bounding_boxes = ocr_result["bounding_boxes"]
        ocr_engine_name = ocr_result["engine_used"]

        # Step 4: Draw Annotated Bounding Boxes
        annotated_filename = f"annotated_{target_filename}"
        annotated_path = os.path.join(upload_dir, annotated_filename)
        ImagePreprocessor.draw_annotated_image(target_path, bounding_boxes, annotated_path)

        # Step 5: 14 FSSAI Rules Verification
        rule_eval = FSSAIRuleVerifier.verify_all(extracted_text, cv_symbol)

        # Step 6: ML Prediction
        ml_eval = ComplianceClassifier.predict(extracted_text)

        # Step 7: Save Scan Record to Database
        scan = ScanRecord(
            filename=target_filename,
            image_path=f"uploads/{target_filename}",
            annotated_image_path=f"uploads/{annotated_filename}",
            preprocessed_image_path=f"uploads/{preprocessed_filename}" if preprocessed_filename else None,
            product_name=display_name,
            original_ocr_text=extracted_text,
            corrected_ocr_text=extracted_text,
            overall_score=rule_eval["score"],
            compliance_status=rule_eval["compliance_status"],
            ml_prediction=ml_eval["prediction"],
            ml_confidence=ml_eval["confidence"],
            ocr_engine=ocr_engine_name,
            bounding_boxes_json=json.dumps(bounding_boxes)
        )
        db.session.add(scan)
        db.session.flush()  # obtain scan.id

        # Save individual field results
        for f_key, f_data in rule_eval["fields"].items():
            field_def = FIELD_DEFINITIONS.get(f_key, {})
            fr = FieldResult(
                scan_id=scan.id,
                field_key=f_key,
                field_name=field_def.get("title", f_key.replace("_", " ").title()),
                status=f_data["status"],
                confidence=f_data["confidence"],
                evidence=f_data["evidence"],
                rules_passed_json=json.dumps(f_data.get("rules_passed", [])),
                recommendation=f_data["recommendation"]
            )
            db.session.add(fr)

        # Step 8: Generate ReportLab PDF
        pdf_filename = f"report_scan_{scan.id}.pdf"
        pdf_path = os.path.join(upload_dir, pdf_filename)
        pdf_data = {
            "id": scan.id,
            "product_name": scan.product_name,
            "date": scan.created_at.strftime("%Y-%m-%d %H:%M"),
            "score": rule_eval["score"],
            "compliance_status": rule_eval["compliance_status"],
            "ml_prediction": ml_eval["prediction"],
            "ml_confidence": ml_eval["confidence"],
            "ocr_engine": ocr_engine_name,
            "status_counts": rule_eval["status_counts"],
            "fields": rule_eval["fields"]
        }
        PDFReportGenerator.generate_report(pdf_data, pdf_path)
        scan.pdf_path = f"uploads/{pdf_filename}"

        db.session.commit()
        return redirect(url_for("verifier.view_scan", scan_id=scan.id))

    # GET request: render verify form
    return render_template("verify.html", fields_definitions=FIELD_DEFINITIONS)


@verifier_bp.route("/verify/<int:scan_id>")
def view_scan(scan_id):
    """Interactive compliance audit dashboard for a specific scan."""
    scan = ScanRecord.query.get_or_404(scan_id)
    scan_dict = scan.to_dict()
    return render_template(
        "verify_results.html",
        scan=scan,
        scan_dict=scan_dict,
        fields_definitions=FIELD_DEFINITIONS
    )


@verifier_bp.route("/api/recheck/<int:scan_id>", methods=["POST"])
def recheck_scan(scan_id):
    """
    Re-evaluates compliance against the 14 FSSAI fields and ML model
    using user-edited/corrected OCR text. Updates the database and regenerates PDF.
    """
    scan = ScanRecord.query.get_or_404(scan_id)
    data = request.get_json() or {}
    new_text = data.get("ocr_text", "").strip()

    if not new_text:
        return jsonify({"success": False, "error": "No OCR text provided."}), 400

    # Re-verify with 14 rules
    rule_eval = FSSAIRuleVerifier.verify_all(new_text)

    # Re-predict with ML model
    ml_eval = ComplianceClassifier.predict(new_text)

    # Update database record
    scan.corrected_ocr_text = new_text
    scan.overall_score = rule_eval["score"]
    scan.compliance_status = rule_eval["compliance_status"]
    scan.ml_prediction = ml_eval["prediction"]
    scan.ml_confidence = ml_eval["confidence"]

    # Update FieldResult entities
    for fr in scan.field_results:
        if fr.field_key in rule_eval["fields"]:
            f_data = rule_eval["fields"][fr.field_key]
            fr.status = f_data["status"]
            fr.confidence = f_data["confidence"]
            fr.evidence = f_data["evidence"]
            fr.rules_passed_json = json.dumps(f_data.get("rules_passed", []))
            fr.recommendation = f_data["recommendation"]

    # Re-generate PDF report
    upload_dir = current_app.config["UPLOAD_FOLDER"]
    pdf_filename = f"report_scan_{scan.id}.pdf"
    pdf_path = os.path.join(upload_dir, pdf_filename)
    pdf_data = {
        "id": scan.id,
        "product_name": scan.product_name,
        "date": scan.created_at.strftime("%Y-%m-%d %H:%M"),
        "score": rule_eval["score"],
        "compliance_status": rule_eval["compliance_status"],
        "ml_prediction": ml_eval["prediction"],
        "ml_confidence": ml_eval["confidence"],
        "ocr_engine": scan.ocr_engine,
        "status_counts": rule_eval["status_counts"],
        "fields": rule_eval["fields"]
    }
    PDFReportGenerator.generate_report(pdf_data, pdf_path)
    scan.pdf_path = f"uploads/{pdf_filename}"

    db.session.commit()

    return jsonify({
        "success": True,
        "scan": scan.to_dict(),
        "rule_eval": rule_eval,
        "ml_eval": ml_eval,
        "pdf_url": url_for("verifier.download_pdf", scan_id=scan.id)
    })


@verifier_bp.route("/download-pdf/<int:scan_id>")
def download_pdf(scan_id):
    """Serves the generated ReportLab PDF audit report."""
    scan = ScanRecord.query.get_or_404(scan_id)
    upload_dir = current_app.config["UPLOAD_FOLDER"]
    pdf_filename = f"report_scan_{scan.id}.pdf"
    pdf_path = os.path.join(upload_dir, pdf_filename)

    if not os.path.exists(pdf_path):
        # Regenerate if missing
        fields_dict = {f.field_key: f.to_dict() for f in scan.field_results}
        status_counts = {"PRESENT": 0, "NEEDS_REVIEW": 0, "INVALID": 0, "MISSING": 0}
        for f in scan.field_results:
            status_counts[f.status] = status_counts.get(f.status, 0) + 1

        pdf_data = {
            "id": scan.id,
            "product_name": scan.product_name,
            "date": scan.created_at.strftime("%Y-%m-%d %H:%M"),
            "score": scan.overall_score,
            "compliance_status": scan.compliance_status,
            "ml_prediction": scan.ml_prediction,
            "ml_confidence": scan.ml_confidence,
            "ocr_engine": scan.ocr_engine,
            "status_counts": status_counts,
            "fields": fields_dict
        }
        PDFReportGenerator.generate_report(pdf_data, pdf_path)

    return send_file(
        pdf_path,
        as_attachment=True,
        download_name=f"FSSAI_Audit_Report_Scan_{scan.id}.pdf",
        mimetype="application/pdf"
    )
