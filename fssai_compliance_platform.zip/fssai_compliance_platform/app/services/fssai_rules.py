"""
FSSAI Food Label Compliance Verification Rule Engine
Based on Food Safety and Standards (Labelling and Display) Regulations, 2020.

Validates the 14 mandatory FSSAI label fields using strict evidence-based rules.
Returns status: 'PRESENT', 'MISSING', 'INVALID', or 'NEEDS_REVIEW'.
Never treats keyword detection alone as proof of compliance.
"""

import re
from datetime import datetime


FIELD_DEFINITIONS = {
    "food_name": {
        "title": "Name of Food",
        "weight": 5,
        "regulation": "FSSAI Regulation 5(1): Declared common or descriptive name of food",
        "description": "Standardised or descriptive product name indicating the true nature of the food."
    },
    "ingredients": {
        "title": "List of Ingredients",
        "weight": 10,
        "regulation": "FSSAI Regulation 5(2): Heading 'Ingredients:' in descending order of weight/volume",
        "description": "Comprehensive list of all ingredients including allergen declarations where applicable."
    },
    "nutrition": {
        "title": "Nutritional Information",
        "weight": 10,
        "regulation": "FSSAI Regulation 5(3): Energy, Protein, Carbs, Total/Added Sugars, Fat, Saturated/Trans Fat, Sodium",
        "description": "Mandatory nutritional breakdown per 100g/ml or per serving."
    },
    "veg_nonveg": {
        "title": "Veg / Non-Veg Symbol",
        "weight": 8,
        "regulation": "FSSAI Regulation 5(4): Green circle in square (Veg) or Brown triangle in square (Non-Veg)",
        "description": "Statutory symbol or logo identifying food as Vegetarian or Non-Vegetarian."
    },
    "additives": {
        "title": "Declaration of Food Additives",
        "weight": 5,
        "regulation": "FSSAI Regulation 5(5): INS Numbers and functional class titles for all additives",
        "description": "International Numbering System (INS) codes or functional class titles."
    },
    "manufacturer": {
        "title": "Manufacturer Name & Address",
        "weight": 10,
        "regulation": "FSSAI Regulation 5(6): Complete postal address of manufacturer/packer with PIN code",
        "description": "Full registered premises address of the food business operator."
    },
    "customer_care": {
        "title": "Customer Care Details",
        "weight": 6,
        "regulation": "FSSAI Regulation 5(7): Telephone, email, and postal grievance address",
        "description": "Consumer helpline number and email for grievances."
    },
    "net_quantity": {
        "title": "Net Quantity",
        "weight": 8,
        "regulation": "FSSAI Regulation 5(8) & Legal Metrology: Standard metric units (g, kg, ml, l)",
        "description": "Net weight or volume in standard metric units."
    },
    "mrp": {
        "title": "Retail Sale Price (MRP)",
        "weight": 8,
        "regulation": "Legal Metrology & FSSAI: MRP inclusive of all taxes declaration",
        "description": "Maximum Retail Price in INR with mandatory taxes inclusion statement."
    },
    "fssai_license": {
        "title": "FSSAI Logo & 14-Digit Licence No.",
        "weight": 10,
        "regulation": "FSSAI Regulation 5(9): 14-digit alphanumeric license number displayed with FSSAI logo",
        "description": "14-digit registration/licence number of the manufacturer/marketer."
    },
    "batch_number": {
        "title": "Lot / Code / Batch Identification",
        "weight": 6,
        "regulation": "FSSAI Regulation 5(10): Batch / Lot identification preceded by 'Batch No' or 'Lot No'",
        "description": "Unique traceability code identifying the production lot."
    },
    "date_marking": {
        "title": "Date Marking (Mfg & Best Before)",
        "weight": 10,
        "regulation": "FSSAI Regulation 5(11): Date of manufacture/packaging and Best Before/Expiry date",
        "description": "Clear chronological manufacturing/packaging date and shelf-life period."
    },
    "instructions": {
        "title": "Instructions for Use & Storage",
        "weight": 2,
        "regulation": "FSSAI Regulation 5(12): Special storage conditions and instructions for preparation",
        "description": "Clear guidelines on storage temperature, shelf handling, and usage."
    },
    "country_of_origin": {
        "title": "Country of Origin",
        "weight": 2,
        "regulation": "FSSAI Regulation 5(13): Mandatory declaration of origin country for packaged foods",
        "description": "Explicit declaration of country where food was manufactured."
    }
}


class FSSAIRuleVerifier:
    """Verifies food label text against all 14 mandatory FSSAI fields."""

    @classmethod
    def verify_all(cls, text, cv_symbol_info=None):
        """
        Executes evidence-based verification for all 14 fields.
        Returns detailed dictionary with field breakdown, score, and recommendations.
        """
        clean_text = str(text or "").strip()
        results = {}
        earned_score = 0
        total_possible = sum(f["weight"] for f in FIELD_DEFINITIONS.values())

        # 1. Food Name
        results["food_name"] = cls._verify_food_name(clean_text)

        # 2. Ingredients
        results["ingredients"] = cls._verify_ingredients(clean_text)

        # 3. Nutrition
        results["nutrition"] = cls._verify_nutrition(clean_text)

        # 4. Veg / Non-Veg
        results["veg_nonveg"] = cls._verify_veg_nonveg(clean_text, cv_symbol_info)

        # 5. Food Additives
        results["additives"] = cls._verify_additives(clean_text)

        # 6. Manufacturer Name & Address
        results["manufacturer"] = cls._verify_manufacturer(clean_text)

        # 7. Customer Care Details
        results["customer_care"] = cls._verify_customer_care(clean_text)

        # 8. Net Quantity
        results["net_quantity"] = cls._verify_net_quantity(clean_text)

        # 9. Retail Sale Price (MRP)
        results["mrp"] = cls._verify_mrp(clean_text)

        # 10. FSSAI License & Logo
        results["fssai_license"] = cls._verify_fssai_license(clean_text)

        # 11. Batch / Lot Number
        results["batch_number"] = cls._verify_batch_number(clean_text)

        # 12. Date Marking (Mfg & Expiry)
        results["date_marking"] = cls._verify_date_marking(clean_text)

        # 13. Instructions & Storage
        results["instructions"] = cls._verify_instructions(clean_text)

        # 14. Country of Origin
        results["country_of_origin"] = cls._verify_country_of_origin(clean_text)

        # Compute Score
        for key, res in results.items():
            weight = FIELD_DEFINITIONS[key]["weight"]
            status = res["status"]
            if status == "PRESENT":
                earned_score += weight
            elif status == "NEEDS_REVIEW":
                earned_score += (weight * 0.5)
            # INVALID and MISSING earn 0

        score_percent = round((earned_score / total_possible) * 100, 1)

        if score_percent >= 85.0:
            compliance_status = "COMPLIANT"
            status_desc = "Meets FSSAI Labelling Regulations (Pass)"
        elif score_percent >= 60.0:
            compliance_status = "PARTIALLY_COMPLIANT"
            status_desc = "Partially Compliant (Minor Omissions Detected)"
        else:
            compliance_status = "NON_COMPLIANT"
            status_desc = "Non-Compliant (Critical Statutory Violations)"

        # Summary counts
        status_counts = {"PRESENT": 0, "NEEDS_REVIEW": 0, "INVALID": 0, "MISSING": 0}
        for res in results.values():
            status_counts[res["status"]] = status_counts.get(res["status"], 0) + 1

        return {
            "score": score_percent,
            "earned_points": earned_score,
            "total_points": total_possible,
            "compliance_status": compliance_status,
            "status_description": status_desc,
            "status_counts": status_counts,
            "fields": results
        }

    # ================= FIELD VALIDATORS =================

    @staticmethod
    def _verify_food_name(text):
        """1. Name of Food"""
        # Look for descriptive product naming
        name_patterns = [
            r"(?:product|item|name of food|food name)\s*[:\-]?\s*([A-Za-z0-9\s\-\&]+)",
            r"\b([A-Za-z\s]+(?:Bread|Nectar|Juice|Chips|Ghee|Butter|Noodles|Cookies|Oil|Powder|Pickle|Yogurt|Chocolate|Cereal|Cheese|Masala|Atta|Flakes|Drink|Sauce))\b"
        ]
        evidence = []
        for pat in name_patterns:
            matches = re.findall(pat, text, re.IGNORECASE)
            if matches:
                evidence.extend([m.strip() for m in matches if len(m.strip()) > 3])

        if evidence:
            candidate = evidence[0]
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": f"Identified food name: '{candidate}'",
                "rules_passed": ["Descriptive food name declared clearly on principal display panel"],
                "recommendation": "Compliant with FSSAI Regulation 5(1)."
            }

        # Check if first line contains text
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        if lines and len(lines[0]) > 3 and not re.search(r"ingredient|mrp|fssai|batch", lines[0], re.I):
            return {
                "status": "NEEDS_REVIEW",
                "confidence": 0.65,
                "evidence": f"First line detected as potential product name: '{lines[0]}'",
                "rules_passed": ["Text header isolated"],
                "recommendation": "Ensure the specific descriptive name of the food is clearly printed on the principal display panel."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "No clear descriptive product name found.",
            "rules_passed": [],
            "recommendation": "FSSAI Regulation 5(1) requires the specific descriptive name of food."
        }

    @staticmethod
    def _verify_ingredients(text):
        """2. List of Ingredients"""
        # Search for Ingredients header
        m = re.search(r"\b(?:Ingredients?|Ingr[eé]dients?)\s*[:\-]\s*(.*?)(?=\b(?:Nutrit|Mfd|Pack|Batch|Net|MRP|FSSAI|Store|Date|Country)\b|$)", text, re.DOTALL | re.IGNORECASE)
        if m:
            content = m.group(1).strip()
            # Strict evidence check: must contain comma or items
            items = [item.strip() for item in content.split(",") if len(item.strip()) > 2]
            if len(items) >= 2 or len(content) > 25:
                # Check for allergen statement
                allergen = "Contains" in content or "Allergen" in text
                return {
                    "status": "PRESENT",
                    "confidence": 0.95,
                    "evidence": f"Ingredients declared: {content[:100]}... ({len(items)} items listed)",
                    "rules_passed": [
                        "Standard 'Ingredients:' heading present",
                        f"Descending order list parsed ({len(items)} components)",
                        "Allergen statement checked" if allergen else "No specific allergen declared"
                    ],
                    "recommendation": "Meets FSSAI Regulation 5(2) requirements."
                }
            elif len(content) > 0:
                return {
                    "status": "NEEDS_REVIEW",
                    "confidence": 0.60,
                    "evidence": f"Truncated ingredients text: '{content}'",
                    "rules_passed": ["Ingredients heading present"],
                    "recommendation": "Ingredients list appears truncated. Ensure all ingredients are declared in descending order of weight/volume."
                }
            else:
                return {
                    "status": "INVALID",
                    "confidence": 0.20,
                    "evidence": "Keyword 'Ingredients:' found but no actual ingredient items follow.",
                    "rules_passed": [],
                    "recommendation": "Keyword alone is insufficient. All ingredients must be listed."
                }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "No ingredient declaration found on label.",
            "rules_passed": [],
            "recommendation": "Mandatory under FSSAI Regulation 5(2) for all multi-ingredient packaged foods."
        }

    @staticmethod
    def _verify_nutrition(text):
        """3. Nutritional Information"""
        has_header = bool(re.search(r"\b(?:Nutrition(?:al)?\s*(?:Info|Information|Facts|Values)?)\b", text, re.IGNORECASE))
        
        # Check mandatory nutrients under 2020 regulations:
        nutrients = {
            "energy": bool(re.search(r"\b(?:Energy|Calories|kcal)\b", text, re.IGNORECASE)),
            "protein": bool(re.search(r"\bProtein\b", text, re.IGNORECASE)),
            "carbs": bool(re.search(r"\b(?:Carbohydrates?|Carbs?)\b", text, re.IGNORECASE)),
            "sugars": bool(re.search(r"\b(?:Sugar|Total Sugars?|Added Sugars?)\b", text, re.IGNORECASE)),
            "fat": bool(re.search(r"\b(?:Total Fat|Fat|Lipids)\b", text, re.IGNORECASE)),
            "sodium": bool(re.search(r"\b(?:Sodium|Salt)\b", text, re.IGNORECASE))
        }

        # Check for numeric measurements
        has_measurements = bool(re.search(r"\b\d+(?:\.\d+)?\s*(?:kcal|kJ|g|mg|mcg)\b", text, re.IGNORECASE))
        found_nutrients = [k for k, v in nutrients.items() if v]

        if has_header and len(found_nutrients) >= 4 and has_measurements:
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": f"Nutritional breakdown verified. Key nutrients found: {', '.join(found_nutrients)} with metric values.",
                "rules_passed": [
                    "Nutrition heading present",
                    f"Nutrient parameters declared ({len(found_nutrients)}/6)",
                    "Metric units (kcal, g, mg) validated"
                ],
                "recommendation": "Compliant with FSSAI Regulation 5(3)."
            }
        elif has_header and len(found_nutrients) >= 2:
            missing_nuts = [k for k, v in nutrients.items() if not v]
            return {
                "status": "NEEDS_REVIEW",
                "confidence": 0.65,
                "evidence": f"Partial nutrition table. Found: {', '.join(found_nutrients)}. Missing: {', '.join(missing_nuts)}.",
                "rules_passed": ["Nutrition heading present", "Partial nutrient list"],
                "recommendation": "Under FSSAI 2020, Energy, Protein, Carbohydrates, Total & Added Sugars, Total Fat, Saturated/Trans Fat, and Sodium are mandatory per 100g/serving."
            }
        elif has_header:
            return {
                "status": "INVALID",
                "confidence": 0.25,
                "evidence": "Keyword 'Nutritional Information' present but no structured numeric values or units found.",
                "rules_passed": [],
                "recommendation": "Declaration is invalid without actual numerical values and units per 100g or per serving."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "Nutritional information table completely missing.",
            "rules_passed": [],
            "recommendation": "Mandatory for all packaged food products under FSSAI 2020."
        }

    @staticmethod
    def _verify_veg_nonveg(text, cv_symbol_info=None):
        """4. Veg / Non-Veg Symbol"""
        # Check CV contour detection first
        cv_detected = False
        cv_type = None
        if cv_symbol_info and cv_symbol_info.get("detected"):
            cv_detected = True
            cv_type = cv_symbol_info.get("type")

        # Text declarations
        veg_text = bool(re.search(r"\b(?:Vegetarian|100%\s*Veg|Green\s*(?:Dot|Logo|Circle|Emblem|Mark)|Veg\s*Symbol)\b", text, re.IGNORECASE))
        nonveg_text = bool(re.search(r"\b(?:Non-Vegetarian|Non\s*Veg|Brown\s*(?:Triangle|Logo|Emblem|Mark))\b", text, re.IGNORECASE))

        # Check for non-veg ingredients conflict (e.g. egg, meat, gelatin)
        has_nonveg_ingredients = bool(re.search(r"\b(?:Egg|Meat|Fish|Chicken|Pork|Beef|Gelatin|Crab|Prawn)\b", text, re.IGNORECASE))

        if cv_detected and cv_type == "VEGETARIAN":
            if has_nonveg_ingredients:
                return {
                    "status": "INVALID",
                    "confidence": 0.90,
                    "evidence": "Green Veg logo detected via OpenCV, but non-vegetarian ingredient (e.g. egg/meat) was found in text!",
                    "rules_passed": ["OpenCV Symbol Contour Isolated"],
                    "recommendation": "Severe violation: Product containing non-veg ingredients cannot bear Vegetarian symbol."
                }
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": "Vegetarian emblem (Green circle inside square) confirmed via OpenCV HSV contour analysis.",
                "rules_passed": ["OpenCV green circular contour verified", "Aspect ratio validated"],
                "recommendation": "Compliant with FSSAI Regulation 5(4)."
            }
        elif cv_detected and cv_type == "NON_VEGETARIAN":
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": "Non-Vegetarian emblem (Brown triangle inside square) confirmed via OpenCV contour analysis.",
                "rules_passed": ["OpenCV brown/red triangular contour verified"],
                "recommendation": "Compliant with FSSAI Regulation 5(4)."
            }
        elif veg_text:
            if has_nonveg_ingredients:
                return {
                    "status": "INVALID",
                    "confidence": 0.85,
                    "evidence": "Text claims Vegetarian, but non-veg ingredients detected in ingredients list.",
                    "rules_passed": [],
                    "recommendation": "Conflicting declaration. Check ingredient source."
                }
            return {
                "status": "PRESENT",
                "confidence": 0.88,
                "evidence": "Vegetarian declaration found in label text: 'Vegetarian / Green Dot Logo declared'.",
                "rules_passed": ["Textual statutory emblem declaration present"],
                "recommendation": "Ensure statutory green square border with green filled circle is visibly printed on the principal display panel."
            }
        elif nonveg_text or has_nonveg_ingredients:
            return {
                "status": "NEEDS_REVIEW",
                "confidence": 0.70,
                "evidence": "Non-vegetarian ingredient/text detected. Statutory brown triangle symbol required.",
                "rules_passed": ["Non-veg classification identified"],
                "recommendation": "Must display brown filled triangle inside brown square border on label."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "Mandatory Veg / Non-Veg symbol and declaration completely absent.",
            "rules_passed": [],
            "recommendation": "FSSAI Regulation 5(4) mandates every packaged food must display either the Veg (Green) or Non-Veg (Brown) logo."
        }

    @staticmethod
    def _verify_additives(text):
        """5. Food Additives Declaration"""
        # Look for INS numbers (e.g. INS 330, INS 211, INS 322, etc.)
        ins_matches = re.findall(r"\b(?:INS\s*(\d+[a-z]?)|E\s*(\d+[a-z]?))\b", text, re.IGNORECASE)
        # Look for class titles
        class_titles = re.findall(
            r"\b(Preservative|Acidity Regulator|Emulsifier|Stabilizer|Antioxidant|Raising Agent|Flavour Enhancer|Colour|Anticaking Agent|Sweetener|Added Flavours)\b",
            text, re.IGNORECASE
        )

        pure_food_keywords = bool(re.search(r"\b(?:100%\s*Pure|Free from Argemone Oil|Clarified Butterfat|Single Ingredient|Ground Dried)\b", text, re.IGNORECASE))

        if ins_matches:
            flattened_codes = [m[0] or m[1] for m in ins_matches]
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": f"Food additives declared with INS codes: {', '.join(flattened_codes)}. Class titles: {', '.join(set(class_titles)) or 'None'}",
                "rules_passed": [
                    f"International Numbering System (INS) codes identified: {', '.join(flattened_codes)}",
                    "Class title declaration checked"
                ],
                "recommendation": "Compliant with FSSAI Regulation 5(5)."
            }
        elif class_titles:
            return {
                "status": "PRESENT",
                "confidence": 0.85,
                "evidence": f"Functional class titles declared: {', '.join(set(class_titles))}",
                "rules_passed": ["Functional additive class titles identified"],
                "recommendation": "Compliant. Mention specific INS numbers alongside class titles where applicable."
            }
        elif pure_food_keywords and not re.search(r"\b(?:Preservative|Artificial|Colour|Flavour)\b", text, re.IGNORECASE):
            return {
                "status": "PRESENT",
                "confidence": 0.90,
                "evidence": "Single-ingredient pure food product; no additives required or declared.",
                "rules_passed": ["Pure / natural food declaration validated"],
                "recommendation": "Not applicable / No food additives used."
            }
        elif re.search(r"\b(?:artificial|flavours?|preservatives?)\b", text, re.IGNORECASE):
            return {
                "status": "INVALID",
                "confidence": 0.40,
                "evidence": "Vague mention of 'flavours' or 'preservative' without mandatory INS numbering or specific class title.",
                "rules_passed": [],
                "recommendation": "Under FSSAI 2020, generic terms are illegal; state exact functional class title and INS numbers."
            }

        return {
            "status": "NEEDS_REVIEW",
            "confidence": 0.50,
            "evidence": "No explicit food additives or INS numbers declared.",
            "rules_passed": [],
            "recommendation": "If additives or flavouring substances are used, declare functional class titles and INS numbers."
        }

    @staticmethod
    def _verify_manufacturer(text):
        """6. Manufacturer Name and Complete Address"""
        m = re.search(r"\b(?:Mfd(?:\s*by)?|Manufactured\s*by|Packed\s*by|Marketed\s*by|Bottled\s*by)\s*[:\-]?\s*(.*?)(?=\b(?:Customer|Care|Net|MRP|FSSAI|Lic|Batch|Date|Storage|Best)\b|$)", text, re.DOTALL | re.IGNORECASE)
        
        # Check for 6-digit Indian PIN code
        pincode_match = re.search(r"\b[1-9][0-9]{2}\s?[0-9]{3}\b", text)

        if m:
            content = m.group(1).strip()
            # Strict evidence check
            has_company = bool(re.search(r"(?:Pvt|Ltd|Foods|Bakers|Coop|Dairy|Mills|Agro|Snacks|Beverages|Enterprises|Industries)", content, re.IGNORECASE))
            has_address = len(content) > 30 or pincode_match is not None

            if has_company and has_address:
                pin_text = f"PIN: {pincode_match.group(0)}" if pincode_match else "PIN omitted"
                return {
                    "status": "PRESENT",
                    "confidence": 0.95,
                    "evidence": f"Manufacturer & address: '{content[:80]}...' ({pin_text})",
                    "rules_passed": [
                        "Manufacturer prefix ('Mfd by') verified",
                        "Company identity isolated",
                        "Postal premises address verified",
                        "6-digit PIN code detected" if pincode_match else "PIN code recommended"
                    ],
                    "recommendation": "Compliant with FSSAI Regulation 5(6)."
                }
            elif has_company:
                return {
                    "status": "NEEDS_REVIEW",
                    "confidence": 0.60,
                    "evidence": f"Manufacturer name found ('{content[:40]}'), but complete postal address/PIN code appears incomplete.",
                    "rules_passed": ["Manufacturer name present"],
                    "recommendation": "Complete postal address with state and 6-digit PIN code is mandatory under FSSAI 2020."
                }
            else:
                return {
                    "status": "INVALID",
                    "confidence": 0.30,
                    "evidence": f"Incomplete manufacturer clause: '{content[:40]}'",
                    "rules_passed": [],
                    "recommendation": "Must declare complete registered premises address."
                }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "Manufacturer / Packer name and address completely missing.",
            "rules_passed": [],
            "recommendation": "Mandatory under FSSAI Regulation 5(6)."
        }

    @staticmethod
    def _verify_customer_care(text):
        """7. Customer Care Details"""
        phone_match = re.search(r"\b(?:1800[-\s]?\d{3}[-\s]?\d{3,4}|\d{4}[-\s]?\d{6,8}|\d{10})\b", text)
        email_match = re.search(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", text)
        header_match = bool(re.search(r"\b(?:Customer\s*(?:Care|Support|Service|Helpline)|Consumer\s*(?:Care|Helpline|Grievance)|Care\s*Email|Feedback)\b", text, re.IGNORECASE))

        if phone_match and email_match:
            return {
                "status": "PRESENT",
                "confidence": 0.98,
                "evidence": f"Customer care phone: {phone_match.group(0)}, Email: {email_match.group(0)}",
                "rules_passed": [
                    "Consumer care heading verified",
                    f"Helpline number validated: {phone_match.group(0)}",
                    f"Email address validated: {email_match.group(0)}"
                ],
                "recommendation": "Compliant with FSSAI Regulation 5(7)."
            }
        elif phone_match or email_match:
            found = f"Phone: {phone_match.group(0)}" if phone_match else f"Email: {email_match.group(0)}"
            return {
                "status": "PRESENT",
                "confidence": 0.85,
                "evidence": f"Customer care contact: {found}",
                "rules_passed": ["Contact channel verified"],
                "recommendation": "Compliant. Providing both toll-free telephone and dedicated email is recommended."
            }
        elif header_match:
            return {
                "status": "INVALID",
                "confidence": 0.20,
                "evidence": "Customer care heading found but no valid telephone number or email address could be parsed.",
                "rules_passed": [],
                "recommendation": "Keyword alone is invalid; provide working telephone helpline or email."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "Customer care details completely absent.",
            "rules_passed": [],
            "recommendation": "Mandatory for consumer grievance under FSSAI Regulation 5(7)."
        }

    @staticmethod
    def _verify_net_quantity(text):
        """8. Net Quantity"""
        # Standard legal metric units: g, kg, ml, l, L
        qty_pattern = r"\b(?:Net\s*(?:Wt\.?|Weight|Qty\.?|Quantity|Volume|Content))\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*(g|gm|kg|ml|mL|l|L|ltr|litre)s?\b"
        m = re.search(qty_pattern, text, re.IGNORECASE)

        # Standalone metric search if prefix omitted
        standalone = re.search(r"\b(\d+(?:\.\d+)?)\s*(g|kg|ml|mL|L)\b", text)

        # Look for unit omission defect (e.g. "Net Quantity: 200" or "Weight: Approx 200")
        defective_m = re.search(r"\b(?:Net\s*(?:Qty|Quantity|Wt|Weight|Volume))\s*[:\-]?\s*(?:Approx\s*)?(\d+)(?!\s*(?:g|kg|ml|l|L))\b", text, re.IGNORECASE)

        if m:
            val, unit = m.group(1), m.group(2)
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": f"Net quantity declared: {val} {unit}",
                "rules_passed": [
                    "Standard 'Net Quantity' prefix verified",
                    "Numerical quantity parsed",
                    f"Legal Metrology metric unit '{unit}' verified"
                ],
                "recommendation": "Compliant with FSSAI Regulation 5(8)."
            }
        elif defective_m:
            return {
                "status": "INVALID",
                "confidence": 0.25,
                "evidence": f"Defective net quantity '{defective_m.group(0)}': Metric unit (g, kg, ml, L) is completely omitted!",
                "rules_passed": [],
                "recommendation": "Illegal under Legal Metrology Act and FSSAI 2020. Metric units must accompany numbers."
            }
        elif standalone and bool(re.search(r"Net", text, re.IGNORECASE)):
            return {
                "status": "PRESENT",
                "confidence": 0.82,
                "evidence": f"Net metric quantity parsed: {standalone.group(0)}",
                "rules_passed": ["Metric weight/volume parsed"],
                "recommendation": "Ensure preceded by 'Net Quantity' or 'Net Weight'."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "Net quantity not detected.",
            "rules_passed": [],
            "recommendation": "Mandatory under FSSAI Regulation 5(8) & Legal Metrology Rules."
        }

    @staticmethod
    def _verify_mrp(text):
        """9. Retail Sale Price (MRP)"""
        mrp_pat = r"\b(?:MRP|Price)\s*[:\-]?\s*(?:Rs\.?|₹|INR)?\s*[:\-]?\s*(\d+(?:\.\d{1,2})?)\b"
        price_match = re.search(mrp_pat, text, re.IGNORECASE)
        tax_clause = bool(re.search(r"\b(?:incl(?:usive)?\.?\s*(?:of\s*(?:all\s*)?)?taxes|incl\.?\s*taxes)\b", text, re.IGNORECASE))

        if price_match and tax_clause:
            return {
                "status": "PRESENT",
                "confidence": 0.98,
                "evidence": f"MRP declared: Rs. {price_match.group(1)} (inclusive of all taxes)",
                "rules_passed": [
                    "MRP indicator verified",
                    f"Retail price value extracted: Rs. {price_match.group(1)}",
                    "Mandatory 'inclusive of all taxes' statutory clause verified"
                ],
                "recommendation": "Compliant with Legal Metrology and FSSAI rules."
            }
        elif price_match:
            return {
                "status": "NEEDS_REVIEW",
                "confidence": 0.70,
                "evidence": f"Price found: Rs. {price_match.group(1)}, but 'inclusive of all taxes' statement was not detected.",
                "rules_passed": ["Price value extracted"],
                "recommendation": "FSSAI and Legal Metrology mandate printing 'inclusive of all taxes' alongside MRP."
            }
        elif re.search(r"\bMRP\b", text, re.IGNORECASE):
            return {
                "status": "INVALID",
                "confidence": 0.30,
                "evidence": "Keyword 'MRP' present but no price digits identified.",
                "rules_passed": [],
                "recommendation": "MRP must state specific numerical price in Indian Rupees."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "Retail sale price (MRP) declaration absent.",
            "rules_passed": [],
            "recommendation": "Mandatory for all retail pre-packaged food commodities."
        }

    @staticmethod
    def _verify_fssai_license(text):
        """10. FSSAI Logo and 14-Digit Licence Number"""
        # Strict 14-digit FSSAI licence pattern
        lic_14_match = re.search(r"\b(?:1\d{13}|2\d{13})\b", text)
        
        # Look for FSSAI prefix with any sequence
        fssai_prefix = re.search(r"\b(?:FSSAI|Lic\.?\s*(?:No\.?|Number)?|License)\s*[:\-]?\s*([A-Za-z0-9_]+)\b", text, re.IGNORECASE)

        if lic_14_match:
            lic_no = lic_14_match.group(0)
            # Check for dummy all-zeros or repetitive digits
            if len(set(lic_no)) <= 2:
                return {
                    "status": "INVALID",
                    "confidence": 0.90,
                    "evidence": f"Suspect dummy licence number: '{lic_no}'",
                    "rules_passed": ["14-digit length check"],
                    "recommendation": "FSSAI licence number must be an authentic 14-digit number issued by Central/State Licensing Authority."
                }
            return {
                "status": "PRESENT",
                "confidence": 0.98,
                "evidence": f"Valid 14-digit FSSAI Licence Number: {lic_no}",
                "rules_passed": [
                    "FSSAI designation verified",
                    "Mandatory 14-digit numeric length validated",
                    f"Valid state/central prefix: {lic_no[:3]}"
                ],
                "recommendation": "Compliant with FSSAI Regulation 5(9)."
            }
        elif fssai_prefix:
            extracted_val = fssai_prefix.group(1).strip()
            digit_count = len(re.sub(r"\D", "", extracted_val))
            return {
                "status": "INVALID",
                "confidence": 0.92,
                "evidence": f"Invalid FSSAI licence: '{extracted_val}' ({digit_count} digits found instead of mandatory 14 digits).",
                "rules_passed": [],
                "recommendation": "Major violation: FSSAI licence number must be exactly 14 digits."
            }
        elif re.search(r"\bfssai\b", text, re.IGNORECASE):
            return {
                "status": "INVALID",
                "confidence": 0.40,
                "evidence": "FSSAI logo / keyword present, but 14-digit licence number is missing.",
                "rules_passed": [],
                "recommendation": "FSSAI logo must always be accompanied by the 14-digit licence number."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "FSSAI logo and 14-digit licence number completely missing.",
            "rules_passed": [],
            "recommendation": "Mandatory under Section 31 of Food Safety and Standards Act, 2006."
        }

    @staticmethod
    def _verify_batch_number(text):
        """11. Lot / Code / Batch Identification"""
        batch_match = re.search(r"\b(?:Batch\s*(?:No\.?|Number|#)?|Lot\s*(?:No\.?|Number|#)?|B\.No\.?)\s*[:\-]?\s*([A-Za-z0-9\-]+)\b", text, re.IGNORECASE)

        if batch_match:
            val = batch_match.group(1).strip()
            if val.lower() in ["none", "nil", "na", "missing", "0", ""]:
                return {
                    "status": "INVALID",
                    "confidence": 0.30,
                    "evidence": f"Invalid batch placeholder: '{val}'",
                    "rules_passed": [],
                    "recommendation": "A unique traceable production batch code is mandatory."
                }
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": f"Batch identification code: '{val}'",
                "rules_passed": [
                    "Batch/Lot prefix verified",
                    "Alphanumeric batch code parsed"
                ],
                "recommendation": "Compliant with FSSAI Regulation 5(10)."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "Lot / Code / Batch identification number not detected.",
            "rules_passed": [],
            "recommendation": "Mandatory for traceability under FSSAI Regulation 5(10)."
        }

    @staticmethod
    def _verify_date_marking(text):
        """12. Date Marking (Mfg & Expiry / Best Before)"""
        mfg_match = re.search(r"\b(?:Mfg(?:\s*Date)?|Mfg\.?|Date\s*of\s*(?:Mfg|Packaging|Packing)|Pkd(?:\s*Date)?|Packed\s*on)\s*[:\-]?\s*([A-Za-z0-9\/\.\-]+)\b", text, re.IGNORECASE)
        exp_match = re.search(r"\b(?:Best\s*Before|Expiry(?:\s*Date)?|Use\s*by|Exp\.?)\s*[:\-]?\s*([A-Za-z0-9\/\.\-\s]+?)(?=\.|\n|$|\b(?:Store|Mfd|Batch|MRP)\b)", text, re.IGNORECASE)

        has_mfg = mfg_match is not None
        has_exp = exp_match is not None

        # Check for invalid informal dates like "Today"
        if (mfg_match and "today" in mfg_match.group(1).lower()) or (exp_match and "fresh" in exp_match.group(1).lower()):
            return {
                "status": "INVALID",
                "confidence": 0.85,
                "evidence": "Informal or vague date marking detected (e.g. 'Today' / 'Consume fresh').",
                "rules_passed": [],
                "recommendation": "FSSAI requires date in DD/MM/YY or MM/YY format or 'X months from manufacture'."
            }

        if has_mfg and has_exp:
            mfg_val = mfg_match.group(1).strip()
            exp_val = exp_match.group(1).strip()
            return {
                "status": "PRESENT",
                "confidence": 0.98,
                "evidence": f"Mfg/Pkg Date: '{mfg_val}', Shelf-life / Expiry: '{exp_val}'",
                "rules_passed": [
                    f"Date of manufacture parsed: {mfg_val}",
                    f"Best before / expiry statement parsed: {exp_val}",
                    "Chronological format verified"
                ],
                "recommendation": "Compliant with FSSAI Regulation 5(11)."
            }
        elif has_mfg:
            return {
                "status": "NEEDS_REVIEW",
                "confidence": 0.60,
                "evidence": f"Manufacturing date found ('{mfg_match.group(1)}'), but Best Before / Expiry date is absent.",
                "rules_passed": ["Manufacturing date verified"],
                "recommendation": "Best Before date or Expiry date is mandatory under FSSAI 2020."
            }
        elif has_exp:
            return {
                "status": "NEEDS_REVIEW",
                "confidence": 0.60,
                "evidence": f"Expiry date found ('{exp_match.group(1)}'), but Manufacturing / Packaging date is absent.",
                "rules_passed": ["Expiry date verified"],
                "recommendation": "Date of manufacture/packaging is mandatory under FSSAI 2020."
            }

        return {
            "status": "MISSING",
            "confidence": 0.0,
            "evidence": "Manufacturing and Expiry date declarations completely absent.",
            "rules_passed": [],
            "recommendation": "Mandatory under FSSAI Regulation 5(11)."
        }

    @staticmethod
    def _verify_instructions(text):
        """13. Instructions for Use & Storage"""
        storage_match = re.search(r"\b(?:Store\s*in\s*a?\s*cool|Keep\s*refrigerated|Keep\s*dry|Store\s*away|Store\s*at|Keep\s*in\s*airtight|Store\s*in\s*dark)\b", text, re.IGNORECASE)
        usage_match = re.search(r"\b(?:Shake\s*well|Ready\s*to\s*eat|Boil\s*in|Do\s*not\s*consume\s*if|Preparation|Refrigerate\s*after\s*opening)\b", text, re.IGNORECASE)

        if storage_match and usage_match:
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": "Both storage conditions and specific usage instructions verified.",
                "rules_passed": ["Storage guidance parsed", "Usage/handling instructions parsed"],
                "recommendation": "Compliant with FSSAI Regulation 5(12)."
            }
        elif storage_match or usage_match:
            evidence_str = "Storage conditions verified." if storage_match else "Handling instructions verified."
            return {
                "status": "PRESENT",
                "confidence": 0.88,
                "evidence": evidence_str,
                "rules_passed": ["Mandatory guidance identified"],
                "recommendation": "Compliant with FSSAI Regulation 5(12)."
            }

        return {
            "status": "NEEDS_REVIEW",
            "confidence": 0.40,
            "evidence": "No clear storage conditions or usage instructions detected.",
            "rules_passed": [],
            "recommendation": "Mandatory where special conditions are required to maintain product integrity."
        }

    @staticmethod
    def _verify_country_of_origin(text):
        """14. Country of Origin"""
        origin_match = re.search(r"\b(?:Product\s*of\s*India|Made\s*in\s*India|Country\s*of\s*Origin\s*[:\-]?\s*([A-Za-z]+)|Imported\s*(?:from|by))\b", text, re.IGNORECASE)

        if origin_match:
            val = origin_match.group(0).strip()
            return {
                "status": "PRESENT",
                "confidence": 0.95,
                "evidence": f"Country of origin declared: '{val}'",
                "rules_passed": ["Statutory origin country verified"],
                "recommendation": "Compliant with FSSAI Regulation 5(13)."
            }

        return {
            "status": "NEEDS_REVIEW",
            "confidence": 0.40,
            "evidence": "Explicit Country of Origin declaration not detected.",
            "rules_passed": [],
            "recommendation": "Mandatory for all packaged food products under FSSAI 2020."
        }
