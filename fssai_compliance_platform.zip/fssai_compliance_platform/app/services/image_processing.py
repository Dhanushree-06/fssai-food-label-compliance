"""
OpenCV Image Preprocessing and Computer Vision Service
AI-Based Food Label Compliance Verification Platform
"""

import os
import cv2
import numpy as np


class ImagePreprocessor:
    """Provides OpenCV image transformations and symbol detection for food labels."""

    @staticmethod
    def deskew_image(image):
        """Detects text skew angle and rotates the image to upright orientation."""
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            blur = cv2.GaussianBlur(gray, (5, 5), 0)
            thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

            # Find coordinates of all foreground pixels
            coords = np.column_stack(np.where(thresh > 0))
            if len(coords) < 50:
                return image, 0.0

            angle = cv2.minAreaRect(coords)[-1]
            if angle < -45:
                angle = -(90 + angle)
            elif angle > 45:
                angle = 90 - angle
            else:
                angle = -angle

            # Clamp extreme or spurious angles to avoid flipping valid labels
            if abs(angle) > 30.0 or abs(angle) < 0.5:
                return image, 0.0

            (h, w) = image.shape[:2]
            center = (w // 2, h // 2)
            rot_mat = cv2.getRotationMatrix2D(center, angle, 1.0)
            rotated = cv2.warpAffine(
                image, rot_mat, (w, h),
                flags=cv2.INTER_CUBIC,
                borderMode=cv2.BORDER_REPLICATE
            )
            return rotated, round(float(angle), 2)
        except Exception as e:
            print(f"[OpenCV] Deskew error: {e}")
            return image, 0.0

    @staticmethod
    def enhance_contrast(gray_image):
        """Applies CLAHE (Contrast Limited Adaptive Histogram Equalization)."""
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        return clahe.apply(gray_image)

    @classmethod
    def preprocess_pipeline(cls, image_path, options=None):
        """
        Executes a modular OpenCV preprocessing pipeline on the input food label image.
        
        Options:
            - enable_deskew: bool (default True)
            - enable_denoise: bool (default True)
            - enable_clahe: bool (default True)
            - enable_threshold: bool (default True)
        """
        if options is None:
            options = {
                "enable_deskew": True,
                "enable_denoise": True,
                "enable_clahe": True,
                "enable_threshold": True
            }

        img = cv2.imread(image_path)
        if img is None:
            raise FileNotFoundError(f"Could not load image at {image_path}")

        orig_h, orig_w = img.shape[:2]
        deskew_angle = 0.0

        # Step 1: Deskew
        if options.get("enable_deskew", True):
            img, deskew_angle = cls.deskew_image(img)

        # Step 2: Grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Step 3: Bilateral Denoising (preserves text edges while removing grain)
        if options.get("enable_denoise", True):
            denoised = cv2.bilateralFilter(gray, d=9, sigmaColor=75, sigmaSpace=75)
        else:
            denoised = gray

        # Step 4: CLAHE Contrast Adjustment
        if options.get("enable_clahe", True):
            enhanced = cls.enhance_contrast(denoised)
        else:
            enhanced = denoised

        # Step 5: Adaptive Gaussian Thresholding
        if options.get("enable_threshold", True):
            binarized = cv2.adaptiveThreshold(
                enhanced, 255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, 15, 8
            )
        else:
            binarized = enhanced

        # Save processed debug preview
        dir_name = os.path.dirname(image_path)
        base_name = os.path.basename(image_path)
        processed_filename = f"preproc_{base_name}"
        processed_path = os.path.join(dir_name, processed_filename)
        cv2.imwrite(processed_path, binarized)

        return {
            "original_shape": (orig_h, orig_w),
            "deskew_angle": deskew_angle,
            "processed_path": processed_path,
            "processed_filename": processed_filename,
            "processed_image": binarized
        }

    @staticmethod
    def detect_veg_nonveg_symbol(image_path):
        """
        Analyzes the image for FSSAI Vegetarian (Green circle in square)
        or Non-Vegetarian (Brown triangle in square) logos.
        """
        img = cv2.imread(image_path)
        if img is None:
            return {"detected": False, "type": "UNKNOWN", "confidence": 0.0, "details": "Image load failed"}

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h, w = img.shape[:2]
        total_pixels = h * w

        # Green HSV range for Vegetarian Logo
        lower_green = np.array([35, 60, 60])
        upper_green = np.array([85, 255, 255])
        green_mask = cv2.inRange(hsv, lower_green, upper_green)

        # Brown/Red HSV range for Non-Vegetarian Logo
        lower_brown = np.array([5, 70, 40])
        upper_brown = np.array([20, 255, 200])
        brown_mask = cv2.inRange(hsv, lower_brown, upper_brown)

        # Also lower red
        lower_red = np.array([0, 100, 100])
        upper_red = np.array([10, 255, 255])
        red_mask = cv2.inRange(hsv, lower_red, upper_red)
        nonveg_mask = cv2.bitwise_or(brown_mask, red_mask)

        # Analyze Green Contours
        green_contours, _ = cv2.findContours(green_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in green_contours:
            area = cv2.contourArea(cnt)
            if 150 < area < (total_pixels * 0.15):
                x, y, cw, ch = cv2.boundingRect(cnt)
                aspect_ratio = float(cw) / max(ch, 1)
                if 0.75 <= aspect_ratio <= 1.35:
                    # Check circularity: 4*pi*area / perimeter^2
                    perimeter = cv2.arcLength(cnt, True)
                    if perimeter > 0:
                        circularity = 4 * np.pi * (area / (perimeter * perimeter))
                        if circularity > 0.45:
                            return {
                                "detected": True,
                                "type": "VEGETARIAN",
                                "confidence": round(min(0.95, circularity), 2),
                                "box": [int(x), int(y), int(cw), int(ch)],
                                "details": "Green circular emblem inside square detected via OpenCV HSV filter"
                            }

        # Analyze Non-Veg Contours
        nonveg_contours, _ = cv2.findContours(nonveg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in nonveg_contours:
            area = cv2.contourArea(cnt)
            if 150 < area < (total_pixels * 0.15):
                x, y, cw, ch = cv2.boundingRect(cnt)
                aspect_ratio = float(cw) / max(ch, 1)
                if 0.7 <= aspect_ratio <= 1.4:
                    # Check triangularity via contour approximation
                    approx = cv2.approxPolyDP(cnt, 0.04 * cv2.arcLength(cnt, True), True)
                    if len(approx) in [3, 4]:
                        return {
                            "detected": True,
                            "type": "NON_VEGETARIAN",
                            "confidence": 0.88,
                            "box": [int(x), int(y), int(cw), int(ch)],
                            "details": "Brown/Red triangle emblem detected via OpenCV HSV contour analysis"
                        }

        return {
            "detected": False,
            "type": "NOT_DETECTED",
            "confidence": 0.0,
            "box": None,
            "details": "No distinct green circle or brown triangle contour isolated"
        }

    @staticmethod
    def draw_annotated_image(image_path, bounding_boxes, output_path):
        """Draws bounding boxes and labels onto the image for web visualization."""
        img = cv2.imread(image_path)
        if img is None:
            return None

        h, w = img.shape[:2]
        for box_info in bounding_boxes:
            box = box_info.get("box", [])
            text = box_info.get("text", "")
            conf = box_info.get("confidence", 0.0)
            if len(box) == 4:
                x, y, bw, bh = box
                # Clamp within image bounds
                x = max(0, min(x, w - 1))
                y = max(0, min(y, h - 1))
                bw = min(bw, w - x)
                bh = min(bh, h - y)

                cv2.rectangle(img, (x, y), (x + bw, y + bh), (30, 180, 70), 2)
                # Label background
                label = f"{text[:18]}.. ({int(conf*100)}%)" if len(text) > 18 else f"{text} ({int(conf*100)}%)"
                (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.45, 1)
                cv2.rectangle(img, (x, max(0, y - 18)), (x + tw + 6, y), (30, 180, 70), -1)
                cv2.putText(
                    img, label, (x + 3, max(12, y - 4)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA
                )

        cv2.imwrite(output_path, img)
        return output_path
