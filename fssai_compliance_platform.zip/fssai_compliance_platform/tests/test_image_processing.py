"""
Unit Tests for OpenCV Image Preprocessing Service
"""

import os
import cv2
import numpy as np
from app.services.image_processing import ImagePreprocessor


SAMPLE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "app", "static", "sample_images"
)


def test_deskew_image_synthetic():
    """Verify deskew function handles synthetic test image without errors."""
    dummy_img = np.ones((300, 300, 3), dtype=np.uint8) * 255
    cv2.putText(dummy_img, "FSSAI TEST LABEL", (30, 150), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 0), 2)
    rotated, angle = ImagePreprocessor.deskew_image(dummy_img)
    assert rotated.shape == dummy_img.shape
    assert isinstance(angle, float)


def test_enhance_contrast():
    """Verify CLAHE contrast enhancement."""
    gray = np.ones((200, 200), dtype=np.uint8) * 128
    enhanced = ImagePreprocessor.enhance_contrast(gray)
    assert enhanced.shape == gray.shape


def test_preprocess_pipeline_on_sample():
    """Verify full preprocessing pipeline on generated sample image."""
    sample_path = os.path.join(SAMPLE_DIR, "sample_snack_pack.png")
    if os.path.exists(sample_path):
        res = ImagePreprocessor.preprocess_pipeline(sample_path)
        assert "processed_path" in res
        assert os.path.exists(res["processed_path"])
        assert "deskew_angle" in res
        assert res["original_shape"][0] > 0


def test_detect_veg_symbol():
    """Verify green veg circle detection on sample."""
    sample_path = os.path.join(SAMPLE_DIR, "sample_snack_pack.png")
    if os.path.exists(sample_path):
        res = ImagePreprocessor.detect_veg_nonveg_symbol(sample_path)
        assert "detected" in res
        assert res["detected"] is True
        assert res["type"] == "VEGETARIAN"
