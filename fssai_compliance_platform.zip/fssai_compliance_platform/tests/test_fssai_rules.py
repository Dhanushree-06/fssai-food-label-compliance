"""
Unit Tests for 14 FSSAI Mandatory Field Validators
"""

from app.services.fssai_rules import FSSAIRuleVerifier, FIELD_DEFINITIONS



def test_field_definitions_count():
    """Verify that all 14 FSSAI fields are defined."""
    assert len(FIELD_DEFINITIONS) == 14
    total_weight = sum(f["weight"] for f in FIELD_DEFINITIONS.values())
    assert total_weight == 100


def test_food_name_validation():
    """Test Food Name field validation."""
    # Positive
    res = FSSAIRuleVerifier._verify_food_name("WHOLE WHEAT BREAD. Freshly baked.")
    assert res["status"] in ["PRESENT", "NEEDS_REVIEW"]

    # Negative
    res_empty = FSSAIRuleVerifier._verify_food_name("")
    assert res_empty["status"] == "MISSING"


def test_ingredients_validation():
    """Test List of Ingredients validation."""
    # Positive: contains list
    text = "Ingredients: Whole Wheat Flour (60%), Water, Sugar, Edible Vegetable Oil, Salt."
    res = FSSAIRuleVerifier._verify_ingredients(text)
    assert res["status"] == "PRESENT"

    # Invalid: keyword without list
    text_invalid = "Ingredients:"
    res_inv = FSSAIRuleVerifier._verify_ingredients(text_invalid)
    assert res_inv["status"] in ["INVALID", "NEEDS_REVIEW"]

    # Missing
    res_missing = FSSAIRuleVerifier._verify_ingredients("Pure milk product without text.")
    assert res_missing["status"] == "MISSING"


def test_nutrition_validation():
    """Test Nutritional Information validation."""
    # Positive: full table with numbers
    text = "Nutritional Information per 100g: Energy 450 kcal, Protein 8.5g, Carbohydrates 65g, Total Fat 18g, Sodium 420mg."
    res = FSSAIRuleVerifier._verify_nutrition(text)
    assert res["status"] == "PRESENT"

    # Needs review: partial nutrients
    text_partial = "Nutritional Information: Energy 100 kcal, Protein 2g."
    res_part = FSSAIRuleVerifier._verify_nutrition(text_partial)
    assert res_part["status"] == "NEEDS_REVIEW"

    # Invalid: keyword without numbers
    text_empty_nut = "Nutritional Information: high quality natural nutrients."
    res_inv = FSSAIRuleVerifier._verify_nutrition(text_empty_nut)
    assert res_inv["status"] == "INVALID"

    # Missing
    res_miss = FSSAIRuleVerifier._verify_nutrition("No data printed.")
    assert res_miss["status"] == "MISSING"


def test_veg_nonveg_validation():
    """Test Veg / Non-Veg Symbol validation."""
    # Positive text
    text_veg = "Vegetarian Logo (Green Circle in Square) Declared."
    res = FSSAIRuleVerifier._verify_veg_nonveg(text_veg)
    assert res["status"] == "PRESENT"

    # Conflicting / Invalid
    text_conflict = "100% Vegetarian product. Ingredients: Wheat flour, Egg Solids, Salt."
    res_conf = FSSAIRuleVerifier._verify_veg_nonveg(text_conflict)
    assert res_conf["status"] == "INVALID"

    # Missing
    res_miss = FSSAIRuleVerifier._verify_veg_nonveg("Flour, sugar, butter.")
    assert res_miss["status"] == "MISSING"


def test_additives_validation():
    """Test Food Additives INS numbers validation."""
    text = "Contains Preservative (INS 282) and Acidity Regulator (INS 330)."
    res = FSSAIRuleVerifier._verify_additives(text)
    assert res["status"] == "PRESENT"


def test_manufacturer_validation():
    """Test Manufacturer Name & Address validation."""
    # Positive: complete address with PIN
    text = "Manufactured by: Surya Bakers Pvt Ltd, Plot 45, Sector 18, Gurugram, Haryana - 122015."
    res = FSSAIRuleVerifier._verify_manufacturer(text)
    assert res["status"] == "PRESENT"

    # Needs review / incomplete: no PIN or full address
    text_inc = "Manufactured by: Sweet Bakers"
    res_inc = FSSAIRuleVerifier._verify_manufacturer(text_inc)
    assert res_inc["status"] in ["NEEDS_REVIEW", "INVALID"]


def test_customer_care_validation():
    """Test Customer Care contact validation."""
    # Positive
    text = "Customer Care Helpline: 1800-200-8899, Email: care@suryabakers.com"
    res = FSSAIRuleVerifier._verify_customer_care(text)
    assert res["status"] == "PRESENT"

    # Invalid: keyword with 'None'
    text_none = "Customer Care: None"
    res_none = FSSAIRuleVerifier._verify_customer_care(text_none)
    assert res_none["status"] == "INVALID"


def test_net_quantity_validation():
    """Test Net Quantity validation."""
    # Positive
    text = "Net Quantity: 400 g"
    res = FSSAIRuleVerifier._verify_net_quantity(text)
    assert res["status"] == "PRESENT"

    # Invalid: unit omitted
    text_nounit = "Net Quantity: 200"
    res_nounit = FSSAIRuleVerifier._verify_net_quantity(text_nounit)
    assert res_nounit["status"] == "INVALID"


def test_mrp_validation():
    """Test Retail Sale Price (MRP) validation."""
    # Positive
    text = "MRP: Rs. 50.00 (inclusive of all taxes)"
    res = FSSAIRuleVerifier._verify_mrp(text)
    assert res["status"] == "PRESENT"

    # Needs review: taxes clause omitted
    text_notax = "MRP: Rs. 50.00"
    res_notax = FSSAIRuleVerifier._verify_mrp(text_notax)
    assert res_notax["status"] == "NEEDS_REVIEW"


def test_fssai_license_validation():
    """Test FSSAI 14-Digit Licence Number validation."""
    # Positive: authentic 14 digits
    text = "FSSAI Lic. No. 10019064001234"
    res = FSSAIRuleVerifier._verify_fssai_license(text)
    assert res["status"] == "PRESENT"

    # Invalid: only 8 digits
    text_8dig = "FSSAI License: 12345678"
    res_8dig = FSSAIRuleVerifier._verify_fssai_license(text_8dig)
    assert res_8dig["status"] == "INVALID"

    # Missing
    res_miss = FSSAIRuleVerifier._verify_fssai_license("Delicious food product.")
    assert res_miss["status"] == "MISSING"


def test_batch_number_validation():
    """Test Batch Number validation."""
    text = "Batch No: WBD402"
    res = FSSAIRuleVerifier._verify_batch_number(text)
    assert res["status"] == "PRESENT"

    text_nil = "Batch No: None"
    res_nil = FSSAIRuleVerifier._verify_batch_number(text_nil)
    assert res_nil["status"] == "INVALID"


def test_date_marking_validation():
    """Test Date Marking validation."""
    # Positive: both Mfg and Expiry
    text = "Date of Mfg: 12/10/2026. Best Before: 17/10/2026."
    res = FSSAIRuleVerifier._verify_date_marking(text)
    assert res["status"] == "PRESENT"

    # Invalid: informal date
    text_today = "Mfg Date: Today"
    res_today = FSSAIRuleVerifier._verify_date_marking(text_today)
    assert res_today["status"] == "INVALID"


def test_instructions_and_origin():
    """Test Storage Instructions and Country of Origin."""
    text = "Store in a cool and dry place. Country of Origin: India."
    res_inst = FSSAIRuleVerifier._verify_instructions(text)
    res_orig = FSSAIRuleVerifier._verify_country_of_origin(text)
    assert res_inst["status"] == "PRESENT"
    assert res_orig["status"] == "PRESENT"


def test_verify_all_summary_scoring():
    """Test overall scoring and compliance classification."""
    compliant_label = (
        "WHOLE WHEAT BREAD. "
        "Ingredients: Whole Wheat Flour (62%), Water, Yeast, Sugar, Salt, Edible Vegetable Oil, Preservative (INS 282). "
        "Nutritional info per 100g: Energy 245 kcal, Protein 8.5g, Carbohydrates 48g, Total Sugars 4.2g, Added Sugars 3.0g, Total Fat 2.1g, Sodium 420mg. "
        "Vegetarian Logo (Green Circle in Square). "
        "Mfd by: Surya Bakers Pvt Ltd, Plot 45, Sector 18, Gurugram, Haryana - 122015. "
        "Customer Care: 1800-200-8899, care@suryabakers.com. "
        "Net Wt: 400 g. MRP Rs. 50.00 (inclusive of all taxes). "
        "FSSAI Lic. No. 10019064001234. Batch No: WBD402. "
        "Mfg: 12/10/2026. Best Before: 17/10/2026. "
        "Store in a cool and dry place. Product of India."
    )
    result = FSSAIRuleVerifier.verify_all(compliant_label)
    assert result["score"] >= 85.0
    assert result["compliance_status"] == "COMPLIANT"
    assert len(result["fields"]) == 14
