"""
Integration Tests for Flask Web Application Routes
"""

import os
import json
from app import create_app
from app.models import db, ScanRecord


def get_test_app_and_client():
    """Helper to return an isolated testing app and client."""
    test_app = create_app({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
        "WTF_CSRF_ENABLED": False
    })
    return test_app, test_app.test_client()


def test_home_page(client=None):
    """Verify landing page loads successfully."""
    if client is None:
        _, client = get_test_app_and_client()
    response = client.get("/")
    assert response.status_code == 200
    assert b"FSSAI Verifier" in response.data
    assert b"14 Fields" in response.data


def test_about_page(client=None):
    """Verify about page loads with ML metrics."""
    if client is None:
        _, client = get_test_app_and_client()
    response = client.get("/about")
    assert response.status_code == 200
    assert b"Model Performance" in response.data
    assert b"Confusion Matrix" in response.data


def test_verify_get_page(client=None):
    """Verify check FSSAI label upload page loads."""
    if client is None:
        _, client = get_test_app_and_client()
    response = client.get("/verify")
    assert response.status_code == 200
    assert b"Pre-loaded Sample" in response.data


def test_verify_post_sample(client=None):
    """Verify full label verification workflow with pre-loaded sample."""
    if client is None:
        _, client = get_test_app_and_client()
    response = client.post("/verify", data={
        "sample_choice": "sample_snack_pack.png",
        "enable_deskew": "on",
        "enable_denoise": "on",
        "enable_clahe": "on",
        "enable_threshold": "on"
    }, follow_redirects=True)

    assert response.status_code == 200
    assert b"Audit Results" in response.data
    assert b"Compliance Score" in response.data
    assert b"14 FSSAI Mandatory Fields" in response.data


def test_recheck_api_workflow(client=None):
    """Verify interactive OCR text re-evaluation API endpoint."""
    app_instance, client = get_test_app_and_client()
    
    # First create a scan
    client.post("/verify", data={"sample_choice": "sample_snack_pack.png"})
    
    # Get scan record ID
    with app_instance.app_context():
        scan = ScanRecord.query.first()
        assert scan is not None
        scan_id = scan.id

    # Call /api/recheck/<scan_id>
    updated_ocr = (
        "CRISP KRAFT POTATO CHIPS. "
        "Ingredients: Potatoes (64%), Palmolein Oil, Salt, Spices. "
        "Nutrition per 100g: Energy 540 kcal, Protein 6.8g, Fat 34g, Sodium 780mg. "
        "Vegetarian Green Dot Symbol. "
        "Manufactured by: Crisp Kraft Snacks, GIDC, Sanand, Gujarat - 382110. "
        "Customer Care: 1800-200-5544, care@crispkraft.in. "
        "Net Quantity: 115 g. MRP: Rs. 40.00 incl. of all taxes. "
        "FSSAI Lic. No. 10017042001923. Batch No: SPK8812. "
        "Date of Pkg: 15/09/2026. Best Before 4 months. "
        "Store in a cool dry place. Country of Origin: India."
    )

    recheck_resp = client.post(
        f"/api/recheck/{scan_id}",
        data=json.dumps({"ocr_text": updated_ocr}),
        content_type="application/json"
    )

    assert recheck_resp.status_code == 200
    res_json = recheck_resp.get_json()
    assert res_json["success"] is True
    assert "scan" in res_json
    assert res_json["scan"]["overall_score"] >= 80.0


def test_history_and_export(client=None):
    """Verify history page, search filter, and CSV export."""
    app_instance, client = get_test_app_and_client()
    
    # Create sample scan
    client.post("/verify", data={"sample_choice": "sample_mango_juice.png"})

    # History view
    hist_resp = client.get("/history")
    assert hist_resp.status_code == 200
    assert b"Audit Verification History" in hist_resp.data

    # CSV Export
    csv_resp = client.get("/history/export-csv")
    assert csv_resp.status_code == 200
    assert "text/csv" in csv_resp.content_type
    assert b"Compliance Score (%)" in csv_resp.data


def test_api_verify_text(client=None):
    """Verify standalone REST API text verification."""
    if client is None:
        _, client = get_test_app_and_client()
    payload = {
        "text": (
            "Whole Wheat Bread. Ingredients: Flour, Water, Yeast. "
            "Nutrition per 100g: Energy 250 kcal, Protein 8g, Carbs 50g, Fat 2g, Sodium 400mg. "
            "Green Vegetarian Logo. Mfd by: Baker Co, Sector 10, Delhi - 110001. "
            "Customer Helpline: 1800-111-222, info@baker.com. "
            "Net Wt: 400 g. MRP Rs 45.00 incl of taxes. "
            "FSSAI Lic. No. 10019064001234. Batch: B101. Mfg: 10/10/2026. Best Before: 15/10/2026. "
            "Store in a cool dry place. Product of India."
        )
    }
    resp = client.post("/api/verify_text", data=json.dumps(payload), content_type="application/json")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["success"] is True
    assert data["compliance_status"] == "COMPLIANT"
    assert data["score"] >= 85.0


def test_download_zip_route(client=None):
    """Verify project ZIP download endpoint."""
    if client is None:
        _, client = get_test_app_and_client()
    resp = client.get("/download-zip")
    assert resp.status_code == 200
    assert resp.mimetype == "application/zip"
