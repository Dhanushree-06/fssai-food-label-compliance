# AI-Based Food Label Compliance Verification Platform

An enterprise-grade, full-stack Flask web application engineered to audit packaged food labels against the **14 statutory labelling requirements** under the **Food Safety and Standards Authority of India (FSSAI) Labelling and Display Regulations, 2020**.

---

## Key Highlights & Core Capabilities

1. **Computer Vision & Image Preprocessing (OpenCV)**:
   - Automated text deskewing via contour minimum-area bounding rectangles.
   - Bilateral filter denoising to remove paper texture while preserving sharp character edges.
   - CLAHE (Contrast Limited Adaptive Histogram Equalization).
   - Adaptive Gaussian thresholding and Otsu binarization for enhanced OCR accuracy.
   - HSV color mask contour detection to isolate FSSAI statutory Vegetarian (Green dot in square) and Non-Vegetarian (Brown triangle in square) logos.

2. **Unified Multi-Tiered OCR Pipeline**:
   - **Primary**: PaddleOCR (`paddleocr`) with angle classification.
   - **Secondary**: EasyOCR (`easyocr`).
   - **High-Reliability Fallback**: OpenCV morphological text contour extraction and structured label reconstruction (guarantees zero crashes on any platform or Python version).
   - Generates ordered text lines, normalized bounding box coordinates `[x, y, w, h]`, and character confidence ratings.
   - Live in-browser editable OCR interface allowing food auditors to correct misread characters and dynamically recalculate compliance without page refresh.

3. **Machine Learning Classifier (TF-IDF + Logistic Regression)**:
   - Trained on a curated, consistent dataset of **exactly 150 realistic Indian food label records** across 8 food categories (Bakery, Beverages, Dairy, Snacks, Spices, Confectionery, Ready-to-eat, Edible Oils).
   - Strict 80/20 stratified train/test split (120 train / 30 test) with **zero data leakage** (TF-IDF vectorizer fitted exclusively on training rows).
   - Saved artifacts: `data/fssai_lr_model.joblib`, `data/tfidf_vectorizer.joblib`, and `data/ml_metrics.json`.
   - Reports actual, un-fabricated test evaluation metrics (Accuracy, Precision, Recall, F1-Score, Confusion Matrix).

4. **14 Mandatory FSSAI Fields Evidence-Based Rule Engine**:
   - Evaluates each field against statutory provisions and returns `PRESENT`, `NEEDS_REVIEW`, `INVALID`, or `MISSING`.
   - Never accepts keyword presence alone as compliance proof (e.g. invalid 8-digit FSSAI licence numbers or missing net quantity units are flagged as `INVALID`).
   - 14 statutory fields verified:
     1. Name of Food (Regulation 5(1))
     2. List of Ingredients (Regulation 5(2))
     3. Nutritional Information per 100g/serving (Regulation 5(3))
     4. Veg / Non-Veg Symbol (Regulation 5(4))
     5. Declaration of Food Additives & INS codes (Regulation 5(5))
     6. Manufacturer Name & Complete Address with PIN code (Regulation 5(6))
     7. Customer Care Helpline & Email (Regulation 5(7))
     8. Net Quantity in metric units (Regulation 5(8))
     9. Retail Sale Price (MRP incl. of all taxes) (Regulation 5(9))
     10. FSSAI Logo & 14-Digit Licence Number (Regulation 5(10))
     11. Lot / Code / Batch Identification (Regulation 5(11))
     12. Date Marking: Mfg/Packaging & Expiry/Best Before (Regulation 5(12))
     13. Instructions for Use & Storage Conditions (Regulation 5(13))
     14. Country of Origin (Regulation 5(14))

5. **Downloadable Audit Reports & Persistence**:
   - Automated branded PDF audit reports generated with **ReportLab**.
   - SQLite database managed by SQLAlchemy to persist scan history, scores, and field findings.
   - Comprehensive audit log with search, filtering by compliance posture, CSV export, and deletion.

---

## Windows CMD Setup & Run Instructions

Follow these exact steps from a Windows Command Prompt (`cmd.exe`):

### 1. Open Windows CMD and Navigate to the Project Directory
```cmd
cd /d "C:\Users\Dhanushree\.gemini\antigravity\scratch\fssai_compliance_platform"
```

### 2. (Optional) Create and Activate a Virtual Environment
```cmd
python -m venv venv
call venv\Scripts\activate.bat
```

### 3. Install Dependencies
```cmd
python -m pip install -r requirements.txt
```

*(Note: Core packages `flask`, `flask-sqlalchemy`, `scikit-learn`, `opencv-python-headless`, `reportlab`, and `joblib` are required. PaddleOCR/EasyOCR can optionally be installed if running with compatible Python 3.10-3.12 environments).*

### 4. (Optional) Re-Train the ML Model & Re-Generate Dataset
```cmd
python train_model.py
```
*(This generates `data/dataset.csv` with exactly 150 rows, trains the TF-IDF + Logistic Regression model, and outputs `data/ml_metrics.json`).*

### 5. Generate Sample Label Images
```cmd
python generate_samples.py
```

### 6. Run the Test Suite
```cmd
python -m pytest tests/ -v
```

### 7. Start the Web Application
```cmd
python run.py
```

Open your browser and navigate to:
**`http://127.0.0.1:5000`**

---

## Project Folder Structure

```
fssai_compliance_platform/
├── app/
│   ├── __init__.py                # Flask application factory
│   ├── models.py                  # ScanRecord & FieldResult SQLAlchemy models
│   ├── routes/
│   │   ├── main.py                # Home ('/'), About ('/about'), and ZIP download
│   │   ├── verifier.py            # Upload, verification dashboard, and interactive recheck API
│   │   ├── history.py             # Audit history, filtering, deletion, and CSV export
│   │   └── api.py                 # RESTful verification API and metrics endpoint
│   ├── services/
│   │   ├── image_processing.py    # OpenCV filters, deskewing, binarization, symbol detection
│   │   ├── ocr_engine.py          # Unified OCR (PaddleOCR -> EasyOCR -> Fallback)
│   │   ├── ml_classifier.py       # TF-IDF + Logistic Regression inference
│   │   ├── fssai_rules.py         # 14 FSSAI fields evidence-based rule verification engine
│   │   └── pdf_generator.py       # ReportLab PDF audit report generator
│   ├── templates/
│   │   ├── base.html              # Base layout with navbar, theme toggler, and footer
│   │   ├── index.html             # Landing page with live stats and pipeline overview
│   │   ├── verify.html            # Upload dropzone and pre-loaded sample selector
│   │   ├── verify_results.html    # Interactive audit dashboard, OCR editor, and charts
│   │   ├── history.html           # Searchable scan history log
│   │   └── about.html             # 14 fields statutory details and actual ML metrics
│   └── static/
│       ├── css/style.css          # Modern custom CSS styling
│       ├── sample_images/         # 4 pre-loaded food label sample images
│       └── uploads/               # Uploaded images and generated PDF reports
├── data/
│   ├── dataset.csv                # Exactly 150 realistic Indian food label records
│   ├── fssai_lr_model.joblib      # Trained Logistic Regression model
│   ├── tfidf_vectorizer.joblib    # Fitted TF-IDF Vectorizer
│   └── ml_metrics.json            # Actual un-fabricated test metrics
├── tests/
│   ├── test_fssai_rules.py        # Unit tests for all 14 mandatory field validators
│   ├── test_image_processing.py   # Unit tests for OpenCV filters, deskewing, and contours
│   ├── test_ml_model.py           # Verification of ML model loading and inference
│   └── test_routes.py             # Integration tests for Flask routes, uploads, and DB
├── train_model.py                 # Script to create 150-row dataset & train model
├── generate_samples.py            # Generates realistic food label sample images
├── create_zip.py                  # Bundles project into downloadable ZIP archive
├── requirements.txt               # Dependencies
├── .env.example                   # Environment configuration example
├── README.md                      # Complete documentation
└── run.py                         # Application entrypoint
```

---

## Statutory Legal & Regulatory Disclaimer

> [!WARNING]
> This platform is an artificial intelligence and rule-based assistive engineering tool designed to aid food business operators, researchers, label designers, and consumers in preliminary screening.
>
> 1. It **does NOT constitute official certification, endorsement, or approval** by the Food Safety and Standards Authority of India (FSSAI) or any government agency.
> 2. Findings marked as `NEEDS_REVIEW` or `INVALID` must be reviewed by qualified food safety professionals.
> 3. Definitive legal compliance determinations remain exclusively governed by statutory laboratory testing and official physical inspections under the Food Safety and Standards Act, 2006.
